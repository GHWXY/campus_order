package com.campus.order.controller;

import com.campus.order.domain.Cart;
import com.campus.order.domain.CartExample;
import com.campus.order.service.CartService;
import com.campus.order.service.MerchantService;
import com.campus.order.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class CartController {
    @Autowired
    private CartService cartService;
    @Autowired
    private ProductService productService;
    @Autowired
    private MerchantService merchantService;

    @PostMapping("/cart")
    public String cart(Cart cart, CartExample cartExample, Model model){
        System.out.println("-----cart-----");
        System.out.println(cart);
        /*加入购物车*/
        int i = cartService.insertSelective(cart);
        System.out.println(i);

        /*查询购物车列表*/
        CartExample.Criteria criteria = cartExample.createCriteria();
        criteria.andUidEqualTo(cart.getUid());
        cartExample.setDistinct(false);
        List<Cart> cartlist = cartService.selectByExample(cartExample);
        System.out.println(cartlist);
        model.addAttribute("cartlist",cartlist);
        return "cart";
    }
}
